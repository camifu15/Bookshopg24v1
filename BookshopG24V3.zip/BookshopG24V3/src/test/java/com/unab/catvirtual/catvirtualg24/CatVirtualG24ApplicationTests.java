package com.unab.catvirtual.catvirtualg24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatVirtualG24ApplicationTests {

    @Test
    void contextLoads() {
    }

}
