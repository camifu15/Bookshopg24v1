package com.unab.catvirtual.catvirtual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatVirtualApplicationTests {

    @Test
    void contextLoads() {
    }

}
